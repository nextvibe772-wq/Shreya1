SHREYA — APK Build Guide (Tablet se, GitHub ke through, PC ki zaroorat nahi)
================================================================================

App: Shreya
Created by: Prafull
CEO (shown in About screen): Prafull Yadav

---------------------------------------------------------------------
STEP 1 — GitHub par upload karo (tablet browser se)
---------------------------------------------------------------------
1. github.com par account banao (agar nahi hai).
2. Naya repository banao, naam: shreya
3. Is poore folder (Shreya_APK_Source) ke andar ke saare files/folders
   (www/, capacitor.config.json, package.json, .github/) us repo mein
   upload kar do ("Add file > Upload files" button se, tablet browser
   se hi ho jayega).
4. Commit / Save kar do.

---------------------------------------------------------------------
STEP 2 — GitHub Actions se APK build karwao
---------------------------------------------------------------------
1. Apne repo ke "Actions" tab par jao.
2. "Build Shreya APK" workflow dikhega — usse open karo.
3. "Run workflow" button dabao (ye tumhare tablet se hi ho sakta hai,
   sara build kaam GitHub ke server par hota hai).
4. 3-6 minute wait karo. Build "green tick" ho jaye to complete.
5. Us workflow run ke andar "Artifacts" section mein
   "Shreya-debug-apk" milega — usse download kar lo.
6. Ye ek .apk file hogi — apne Android phone/tablet par download karke
   install kar lo (Settings > "Install unknown apps" allow karna
   padega pehli baar).

---------------------------------------------------------------------
STEP 3 — App khol ke API daalo
---------------------------------------------------------------------
1. App kholo, "Settings" tab par jao.
2. Apni API Endpoint URL, API Key aur Model Name daalo
   (koi bhi OpenAI-compatible chat API chalegi — OpenAI, OpenRouter,
   ya apna khud ka server).
3. "Save Settings" dabao.
4. Ab Chat tab se baat kar sakte ho, ya mic button dabakar bol sakte ho.

Jab tak API nahi daali hai, tab bhi Shreya kuch basic cheezein handle
kar sakti hai: naam, kisne banaya, time, tareekh, greeting, about.

---------------------------------------------------------------------
IMPORTANT — Imandaari se kuch seemaayein (please padho)
---------------------------------------------------------------------
1. VOICE RECOGNITION (mic se sunna): Android WebView mein browser jaisi
   speech recognition hamesha reliable nahi hoti. Isliye is project mein
   ek native plugin (@capacitor-community/speech-recognition) add kiya
   gaya hai jo GitHub Action build ke dauraan automatically install ho
   jayega. Phir bhi, real device par test karna zaroori hai — agar
   pehli baar kaam na kare, to phone Settings mein app ko "Microphone"
   permission manually allow karo.

2. HAMESHA-ON / BACKGROUND WAKE WORD: Jab app band ho ya phone ka
   screen off ho, tab background mein hamesha "Shreya" sunte rehna
   Android ki battery/security policies ki wajah se possible nahi hai
   (Google Assistant jaise apps ko special system-level permission
   milti hai jo normal apps ko nahi milti). Is app mein wake-word
   sirf tab kaam karega jab app khuli/foreground mein ho.

3. PHONE CALLS/SMS/OTHER APPS CONTROL: Ye is version mein include
   NAHI hai — Android security in cheezon ke liye alag se strict
   permissions aur code maangta hai. Chat + Voice + Custom API
   is version ka core hai.

4. API KEY SAFETY: Key sirf tumhare device ke local storage mein
   save hoti hai, kahin bahar nahi bheji jaati — lekin ye
   "encrypted" nahi hai, sirf local hai. Apni API key kisi aur ke
   saath share na karo.

---------------------------------------------------------------------
FILES IN THIS PROJECT
---------------------------------------------------------------------
www/index.html              -> Poora app (chat, voice, settings, about)
capacitor.config.json       -> App ID/name config (com.prafull.shreya)
package.json                -> Dependencies (Capacitor + voice plugins)
.github/workflows/build-apk.yml -> Cloud APK builder (GitHub Actions)
